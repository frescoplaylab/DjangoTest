from django.apps import AppConfig


class MatsessionConfig(AppConfig):
    name = 'Matsession'
