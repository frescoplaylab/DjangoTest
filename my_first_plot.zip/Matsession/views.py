#from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, get_object_or_404

def displayimage1(request):

    return render(request, 'Matsession/myplot1.html')



