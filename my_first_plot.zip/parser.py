import re
import os

plot_names = ['My_First_plot.png']
plotOfTests = {'test_my_first_plot':'My_First_plot.png'}
imgs_folder = 'result_images/test_plots'
tests_count = len(plot_names)
pass_count = 0
imgs_created = {}
imgs_failed = {}
imgs_error = {}

imgs_created = imgs_created.fromkeys(plot_names, 0)
imgs_failed = imgs_failed.fromkeys(plot_names, 0)
imgs_error = imgs_error.fromkeys(plot_names, 0)

img_files = [ os.path.join(imgs_folder, plot) for plot in plot_names]
for img_file in img_files:
    if os.path.exists(img_file):
        imgs_created[os.path.basename(img_file)] = 1
    
no_of_images_generated = sum(imgs_created.values())

if not os.path.exists('unit.xml'):
    try:
        raise SystemExit
    except SystemExit:
        print(0)
else:
    with open('unit.xml') as fp:
        content = fp.read()

    pattern = re.compile(r'errors="(.+?)".+failures="(.+?)".+tests="(.+?)"')
    pattern2 = re.compile(r'classname="(.+?)"\s+.+<failure')
    pattern3 = re.compile(r'classname="(.+?)"\s+.+<error')
    lines = content.split('\n')
    
    mos = [ pattern2.search(line) for line in lines if pattern2.search(line)]
    
    classnames = [ mo.group(1) for mo in mos ]
    classnames = [ cname.split('.')[-1] for cname in classnames ]
    for cname in classnames:
        imgs_failed[plotOfTests[cname]] = 1
        
    
    mos = [ pattern3.search(line) for line in lines if pattern3.search(line)]
    
    classnames = [ mo.group(1) for mo in mos ]
    classnames = [ cname.split('.')[-1] for cname in classnames ]
    for cname in classnames:
        if cname in plotOfTests:
            imgs_error[plotOfTests[cname]] = 1
        

    m = pattern.search(content)
    
    for plot in plot_names:
        if (imgs_created[plot] == 1) and (imgs_failed[plot] == 0) and (imgs_error[plot] == 0):
            pass_count += 1

    
    pass_percent = int(round((pass_count/tests_count)*100,0))
    print(pass_percent)

        

