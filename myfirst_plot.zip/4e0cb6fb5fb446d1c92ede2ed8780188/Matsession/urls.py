from django.conf.urls import url

from .views import displayimage1

urlpatterns = [
    url(r'^1/$', displayimage1),
]
